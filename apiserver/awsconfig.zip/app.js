const express = require("express");
const app = express();
const cors = require("cors");
const path = require("path");
const mysql = require("./dbconfig/mysql");
// const sqlEvents = require('./dbconfig/events')

app.use(cors());
app.use(function (req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Methods", "DELETE, PUT, GET, POST");
  res.header(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content-Type, Accept"
  );
  next();
});
app.use("/static", express.static(path.join(__dirname, "uploads")));
var Result = require("./responses/result");

const routeAuth = require("./routes/auth");
app.use(routeAuth);

const routelocal = require("./routes/localUpload");
app.use(routelocal);

const routeupload = require("./routes/upload");
app.use(routeupload);

const routeProducts = require("./routes/products");
app.use(routeProducts);

const routeUsers = require("./routes/users");
app.use(routeUsers);


const routeSales = require("./routes/salesReport");
app.use(routeSales);

const routeOrders = require("./routes/orderList");
app.use(routeOrders);

const routeCategory = require("./routes/category");
app.use(routeCategory);
const routeCart = require("./routes/cart");
app.use(routeCart);

let uploadRouter = require('./routes/upload.router.js');
app.use(uploadRouter);

let printRoute = require('./routes/printing.router.js');
app.use(printRoute);
//routes here


var port = process.env.PORT || 3232;
var fetch = require("node-fetch");
app.get("/test-3", async (req, res) => {
  const url = "https://pokeapi.co/api/v2/pokemon/ditto";
  const response = await fetch(url);
  const json = await response.json();
  res.json({ json });
});

//const server = 
app.listen(port, function () {
  console.log(`\n.....Api server listening on port:${port}.....`);
  mysql
    .connectNOW()
    .then(success => {
      if (success) {
        console.log(".....Successfully Connected to MySql.....", success);
        // require("./dbconfig/events");
      }
    })
    .catch(err => {
      console.log(err);
    });
  //open(`http://localhost:8080`, { app: 'chrome' })
});

const MySql = require("./dbconfig/pool")
const pool = new MySql()

app.set('pool', pool);

app.get("/", (request, response) => {
  var result = new Result();
  result.message = "Hello the deployment succeed!!";
  result.error = false
  response.json(result);
});

app.get("/env", (req, res) => {
  var result = new Result();
  result.message = "Hello the deployment succeed!!";
  result.body = [{
    accessKeyId: process.env.ACCESS_KEY_ID || "AKIASH7JNBJIUXMENQIV",
    secretAccessKey: process.env.SECRET_ACCESS_KEY || "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",
    region: process.env.REGION || "us-east-2",
    host: process.env.RDS_HOSTNAME || "localhost",
    user: process.env.RDS_USERNAME || "root",
    password: process.env.RDS_PASSWORD || "",
    database: process.env.RDS_DATABASE || "thesis",
    port: process.env.RDS_PORT || "3306",
    api_url: process.env.API_URL || "http://127.0.0.1",
    api_port: process.env.PORT || "3232"
  }];
  result.error = false
  res.json(result);
});



/*
const bcrypt = require("bcryptjs");
const tokenkey = thesis2020BG9;
const jwt = require("jsonwebtoken");

var schedule = require("node-schedule");
var rule = new schedule.RecurrenceRule();
rule.dayOfWeek = [0, new schedule.Range(0, 6)];
rule.hour = 12;
rule.minute = 2;

schedule.scheduleJob(rule, function() {
  console.log("Today is recognized by Rebecca Black!");
});


*/
